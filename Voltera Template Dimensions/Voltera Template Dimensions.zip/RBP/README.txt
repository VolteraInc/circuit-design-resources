Mechanical Specification for Raspberry Pi Hat can be found at https://github.com/raspberrypi/hats/blob/master/hat-board-mechanical.pdf
